/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

public class GestionPrestamos {
    private PilaTareas pilaPendientes;
    private ColaTareas colaCompletadas;

    public GestionPrestamos() {
        pilaPendientes = new PilaTareas();
        colaCompletadas = new ColaTareas();
    }

    public void agregarPrestamo(String nombre, String descripcion, String material) {
        Prestamo prestamo = new Prestamo(nombre, descripcion, material);
        pilaPendientes.agregarPrestamo(prestamo);
    }

    public void completarPrestamo() {
        if (!pilaPendientes.estaVacia()) {
            Prestamo prestamo = pilaPendientes.eliminarPrestamo();
            colaCompletadas.agregarPrestamo(prestamo);
        } else {
            System.out.println("No hay préstamos pendientes para completar.");
        }
    }

    public void mostrarPrestamosPendientes() {
        System.out.println("Préstamos pendientes:");
        pilaPendientes.mostrarPrestamos();
    }

    public void mostrarPrestamosCompletados() {
        System.out.println("Préstamos completados:");
        colaCompletadas.mostrarPrestamos();
    }

    public static void main(String[] args) {
        GestionPrestamos gestion = new GestionPrestamos();
        gestion.agregarPrestamo("Prestamo 1", "Estudiante: juan ", "probeta");
        gestion.agregarPrestamo("Prestamo 2", "Estudiante: pedro ", "probeta");
        gestion.mostrarPrestamosPendientes();
        
        gestion.completarPrestamo();
        gestion.mostrarPrestamosPendientes();
        gestion.mostrarPrestamosCompletados();
    }
}
