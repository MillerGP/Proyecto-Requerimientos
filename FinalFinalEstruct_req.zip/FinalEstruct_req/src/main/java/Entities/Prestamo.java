/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

public class Prestamo {
    private String nombre;
    private String descripcion;
    private String material;

    public Prestamo(String nombre, String descripcion, String material) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.material = material;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getMaterial() {
        return material;
    }

    @Override
    public String toString() {
        return "Prestamo{" +
                "nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", material='" + material + '\'' +
                '}';
    }
}
