/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

import java.util.LinkedList;
import java.util.Queue;

public class ColaTareas {
    private Queue<Prestamo> colaPrestamos;

    public ColaTareas() {
        colaPrestamos = new LinkedList<>();
    }

    public void agregarPrestamo(Prestamo prestamo) {
        colaPrestamos.offer(prestamo);
    }

    public Prestamo verPrestamo() {
        if (!colaPrestamos.isEmpty()) {
            return colaPrestamos.peek();
        }
        return null;
    }

    public boolean estaVacia() {
        return colaPrestamos.isEmpty();
    }

    public void mostrarPrestamos() {
        for (Prestamo prestamo : colaPrestamos) {
            System.out.println(prestamo);
        }
    }
}
