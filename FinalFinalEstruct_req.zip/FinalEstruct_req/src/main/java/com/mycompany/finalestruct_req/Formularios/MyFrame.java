package com.mycompany.finalestruct_req.Formularios;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyFrame extends JFrame implements Observer {

    private JTextField inputField;
    private JTextField listField;
    private JButton addButton;
    private Subject subject;

    public MyFrame() {
        // Configuración básica del JFrame
        setTitle("Observer Pattern Example");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Inicializar componentes
        inputField = new JTextField();
        inputField.setBounds(50, 50, 300, 30);

        listField = new JTextField();
        listField.setBounds(50, 100, 300, 30);
        listField.setEditable(false);

        addButton = new JButton("Add");
        addButton.setBounds(150, 150, 100, 30);

        // Inicializar subject
        subject = new Subject();
        subject.addObserver(this);

        // Añadir componentes al JFrame
        add(inputField);
        add(listField);
        add(addButton);

        // Añadir funcionalidad al botón
        addButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                String newItem = inputField.getText();
                if (!newItem.isEmpty()) {
                    String currentList = listField.getText();
                    if (currentList.isEmpty()) {
                        listField.setText(newItem);
                    } else {
                        listField.setText(currentList + ", " + newItem);
                    }
                    inputField.setText("");
                    subject.notifyObservers("Nuevo ítem agregado: " + newItem);
                }
            }
        });
    }

    @Override
    public void update(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MyFrame frame = new MyFrame();
            frame.setVisible(true);
        });
    }
}
