
package Cola;

import java.util.LinkedList;
import java.util.Queue;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JPanel;



public class ColaCombo {
    
    public void docs(){
    
        Queue<String> cola = new LinkedList<>();


         // agregar elementos a la cola
         
      cola.add("Elemento 1");
cola.add("Elemento 2");
cola.add("Elemento 3");

        
        
        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setModel(new DefaultComboBoxModel<>());
        
   
        for (String elemento : cola) {
        comboBox.addItem(elemento);
        
        JPanel panel = new JPanel();
        panel.add(comboBox);

}


    
}
}