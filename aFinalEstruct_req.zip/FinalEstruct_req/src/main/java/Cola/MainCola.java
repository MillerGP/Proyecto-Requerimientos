
package Cola;


public class MainCola {
    public static void main(String[] args) {
         
        ColaFrm cola = new ColaFrm();
        cola.docs();
    
    }
}
