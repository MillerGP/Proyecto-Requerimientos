
package Cola;


import java.util.LinkedList;


/**
 * cola
 */
public class ColaFrm {

    public void docs(){

        LinkedList<String> cola = new LinkedList<>(); 
            
   

        // agregar elementos a la cola (push)

        cola.offer("elemento 1");
        cola.offer("elemento 2");
        cola.offer("elemento 3");

        // Mostrar la cola

        System.out.println("cola actual:" +cola);

        // obtener y mostrar el elemento en la cima de la cola sin quitarlo (peek)

         String elementoEncima = cola.peek();
         System.out.println("elemento en la cima: "+ elementoEncima);

        System.out.println("elemento en la cima: "+ cola.peek());

        // retirar el ultimo elemento(pop)
        String elementoAlfrente = cola.poll();
        System.out.println("elemento Alfrente:"+ elementoAlfrente);

      

        // verificar si la cola esta vacia

        boolean estaVacia = cola.isEmpty();
        System.out.println("la cola esta vacia?"+ estaVacia);

        if (cola.isEmpty()) {
            System.out.println("Esta vacia");
        } else {
            System.out.println("Esta llena");
        }




    }
}
