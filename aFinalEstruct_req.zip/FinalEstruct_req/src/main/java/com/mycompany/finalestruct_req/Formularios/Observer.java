
package com.mycompany.finalestruct_req.Formularios;


public interface Observer {
     void update(String message);
}
