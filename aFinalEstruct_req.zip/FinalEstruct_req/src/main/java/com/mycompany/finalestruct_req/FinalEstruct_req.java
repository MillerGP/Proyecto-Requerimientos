
package com.mycompany.finalestruct_req;


public class FinalEstruct_req {

    public static void main(String[] args) {
       
        
        
    }
}
