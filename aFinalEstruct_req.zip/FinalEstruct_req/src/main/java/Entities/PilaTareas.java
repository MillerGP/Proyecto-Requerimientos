/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

import java.util.Stack;

public class PilaTareas {
    private Stack<Prestamo> pilaPrestamos;

    public PilaTareas() {
        pilaPrestamos = new Stack<>();
    }

    public void agregarPrestamo(Prestamo prestamo) {
        pilaPrestamos.push(prestamo);
    }

    public Prestamo eliminarPrestamo() {
        if (!pilaPrestamos.isEmpty()) {
            return pilaPrestamos.pop();
        }
        return null;
    }

    public Prestamo verPrestamo() {
        if (!pilaPrestamos.isEmpty()) {
            return pilaPrestamos.peek();
        }
        return null;
    }

    public boolean estaVacia() {
        return pilaPrestamos.isEmpty();
    }

    public void mostrarPrestamos() {
        for (Prestamo prestamo : pilaPrestamos) {
            System.out.println(prestamo);
        }
    }
}
